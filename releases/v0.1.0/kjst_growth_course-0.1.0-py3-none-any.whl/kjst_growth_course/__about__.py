name = "kjst-growth-course"
version = "0.1.0"
copyright = "Copyright 2025, Contributors to kjst-growth-course"
