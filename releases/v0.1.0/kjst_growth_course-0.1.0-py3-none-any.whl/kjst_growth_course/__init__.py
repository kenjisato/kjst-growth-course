from . import __about__

__version__ = __about__.version
